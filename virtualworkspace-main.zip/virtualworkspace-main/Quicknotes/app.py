from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager,
    UserMixin,
    login_user,
    logout_user,
    login_required,
    current_user
)

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///notes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Flask Login Setup
login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)


class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    content = db.Column(db.Text, nullable=False)

    user_id = db.Column(
        db.Integer,
        db.ForeignKey('user.id'),
        nullable=False
    )

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


@app.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('home'))

    return redirect(url_for('login'))


@app.route('/signup', methods=['GET', 'POST'])
def signup():

    if request.method == 'POST':

        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')

        existing_user = User.query.filter_by(email=email).first()

        if existing_user:
            flash('Email already exists!')
            return redirect(url_for('signup'))

        new_user = User(
            username=username,
            email=email,
            password=password
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Account created successfully!')
        return redirect(url_for('login'))

    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():

    if request.method == 'POST':

        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(
            email=email,
            password=password
        ).first()

        if user:
            login_user(user)
            flash('Login Successful!')
            return redirect(url_for('home'))

        flash('Invalid Email or Password')

    return render_template('login.html')

@app.route('/home')
@login_required
def home():

    notes = Note.query.filter_by(
        user_id=current_user.id
    ).all()

    return render_template(
        'home.html',
        notes=notes
    )


@app.route('/add_note', methods=['POST'])
@login_required
def add_note():

    content = request.form.get('content')

    if content.strip() == '':
        flash('Note cannot be empty!')
        return redirect(url_for('home'))

    note = Note(
        content=content,
        user_id=current_user.id
    )

    db.session.add(note)
    db.session.commit()

    flash('Your note has been added!')
    return redirect(url_for('home'))

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
@login_required
def edit(id):

    note = Note.query.get_or_404(id)

    if note.user_id != current_user.id:
        flash('Unauthorized Access')
        return redirect(url_for('home'))

    if request.method == 'POST':

        note.content = request.form.get('content')

        db.session.commit()

        flash('Note updated successfully!')
        return redirect(url_for('home'))

    return render_template(
        'edit.html',
        note=note
    )

@app.route('/delete/<int:id>')
@login_required
def delete(id):

    note = Note.query.get_or_404(id)

    if note.user_id != current_user.id:
        flash('Unauthorized Access')
        return redirect(url_for('home'))

    db.session.delete(note)
    db.session.commit()

    flash('Note deleted successfully!')
    return redirect(url_for('home'))



@app.route('/logout')
@login_required
def logout():

    logout_user()
    flash('Logged out successfully!')

    return redirect(url_for('login'))



if __name__ == '__main__':

    with app.app_context():
        db.create_all()

    app.run(debug=True)